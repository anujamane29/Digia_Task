import React, { useState } from 'react';
import './App.css';
import Tabs from './Tabs';
import CardList from './CardList';

function App() {
  const [activeTab, setActiveTab] = useState('All'); // Set the initial activeTab to 'All'
  const [filter, setFilter] = useState('All'); // Default filter value
  const [search, setSearch] = useState(''); // State for the search input

  const handleFilterChange = (newFilter) => {
    setFilter(newFilter);
  };

  const handleSearchClick = () => {
    // Filter cards based on the search input value
    const filteredCards = cardData.filter((card) => {
      const searchString = search.toLowerCase();
      return (
        card.name.toLowerCase().includes(searchString) ||
        card.budget_name.toLowerCase().includes(searchString)
        // Add more fields to search if needed
      );
    });

    // Update the filtered cards state (you can use useState for this)

  };

  // Sample card data (replace with your actual data)
  const cardData = [
    // ... (your card data remains the same)
    {
      name: "Linkedin",
      budget_name: "Memberfive",
      card_type: "subscription",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Marketing ads",
      budget_name: "Memberfive",
      card_type: "burner",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Offsite event",
      budget_name: "Memberfive",
      card_type: "burner",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Travel allowance",
      budget_name: "Memberfive",
      card_type: "subscription",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Aws card",
      budget_name: "Memberfiv",
       card_type: "subscription",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    },
    {
      name: "Netflix",
      budget_name: "Memberfiv",
      card_type: "burner",
      amount: "Amount-300 SGD",
      frequency: "Frequency-Monthly",
      expiry: " Expiry-21 July 2021",
      spent: "Spent-7890 SGD",
      balance: "Balance-7890 SGD"
    }
  ];

  return (
    <div className="App">
      <div className="header">
        <h1>Your Cards</h1>
        <div className="filter">
          <select value={filter} onChange={(e) => handleFilterChange(e.target.value)}>
            <option value="All">All</option>
            <option value="burner">Burner</option>
            <option value="subscription">Subscription</option>
          </select>
        </div>
        <div className="search">
          <input
            type="text"
            placeholder="Search..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <i className="fas fa-search" onClick={handleSearchClick}></i>
        </div>
      </div>
      <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />
      <CardList activeTab={activeTab} filter={filter} search={search} />
    </div>
  );
}

export default App;
