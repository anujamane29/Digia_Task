// Tabs.js
import React from "react";

function Tabs({ activeTab, setActiveTab }) {
  const tabs = ["Your", "All", "Blocked"];

  return (
    <div className="tabs">
      {tabs.map((tab) => (
        <button
          key={tab}
          className={`tab-button ${activeTab === tab ? "active" : ""}`}
          onClick={() => setActiveTab(tab)}
        >
          {tab}
        </button>
      ))}
    </div>
  );
}

export default Tabs;